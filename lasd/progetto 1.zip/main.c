#include<stdio.h>
#include<stdlib.h>
#include "Young.h"
#define MAX 32


int main ()
{
	// Dichiarazioni:

	// Matrice statica 32x32
	int A[MAX][MAX];
	// Interi per stabilire quante colonne e righe vogliamo usare
	int numRig,numCol;
	// Numero di elementi che vogliamo inserire nella matrice inizialmente
	int numElem;
	printf("\nInserisci numero righe (Compreso tra 3 e 20)");
	numRig = acquisisci_int(3,20);

	printf("\nInserisci numero colonne (Compreso tra 3 e 20)");
	numCol = acquisisci_int(3,20);


	printf("Quanti elementi vuoi inserire?(Compresi tra 1 e %d): ",(numRig*numCol));
	numElem = acquisisci_int(1,(numRig*numCol));
	int completo;
	completo =((numElem)^(1/2));
	if ((completo*completo)==numElem)
		{
			fill(numElem, completo, completo,A);
		}
	else
		{
			// Inizializza la matrice con il numero di elementi decsisi dall'utente
			fill(numElem, numRig, numCol,A);
		}

	printf ("Matrice inserita:\n\n");
	// Stampa la matrice inserita, con i valori indefiniti settati a 999
	print(numRig,numCol,A);

	printf("Young Tablue:\n\n");
	// Trasforma la matrice originale, in un Tablue Young
	buildYoung( numRig, numCol, A);
	// E la stampa
	print(numRig, numCol, A);

	// Estrae il minimo, e ritorna il numero di elementi -1 se non è piena
	numElem=EstraiMin(numElem, numRig, numCol, A);
	// Stampa la matrice dopo l'estrazione del minimo
	printf("Estraggo dalla matrice il minimo...\n\n ");

	print(numRig, numCol, A);
	//Inserisce un numero nella tabella di Young, se non è piena
	numElem=insert(numElem, numRig, numCol, A);
	printf("Ele:%d\n", numElem);
	print(numRig, numCol, A);

	return 0;
}
