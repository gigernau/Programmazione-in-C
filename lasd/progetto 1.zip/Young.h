


void fill(int numElem, int numRig, int numCol, int A[numRig][numCol]);
void KeepYoung (  int riga, int colonna,int numRig, int numCol, int A[numRig][numCol]);
void print(int numRig, int numCol, int A[numRig][numCol]);
void buildYoung (int numRig, int numCol, int A[numRig][numCol]);
int EstraiMin(int numElem,int numRig, int numCol, int A[numRig][numCol]);
int search(int chiave, int numRig, int numCol, int A[numRig][numCol]);
void KeepYoungReverse(int riga, int colonna, int numRig, int numCol, int A[numRig][numCol]);
int insert(int numElem, int numRig, int numCol, int A[numRig][numCol]);
int acquisisci_int(int a, int b);
//void insert (  int numRig, int numCol, int elem, int inserit, int A[numRig][numCol]);
