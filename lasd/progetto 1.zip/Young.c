#include <stdio.h>
#include <stdlib.h>
#include "Young.h"
#define MAX 32


/*================FUNZIONI E PROCEDURE=======================*/

/** Procedura fill:
 * Descrizione: � una procedura che riempe la matrice con il numero di elementi
 * precedentemente preso in input, e assegna ai restanti il valore
 * indenfinito, il quale per convenzione sara' settato a 999(INT_MAX)
 */
 
void fill(int numElem,int numRig, int numCol, int A[numRig][numCol])
{

	printf("Inserire gli elementi nella matrice compresi tra 1 e 99:\n");
	int ins; //variabile di appoggio per l'inserimento 
	int i,j; // Indici usati per ciclare la struttura
	int count = 0; // Conta gli elementi inseriti


	for ( i = 0 ; i < numRig; i++ )//ciclo for per le righe
		{

			for ( j = 0 ; j < numCol; j++)//ciclo for per le colonne
				{

					if( count < numElem)/*controlla se il mio contatore � piu piccolo del
										numero massimo degli elementi che posso inserire*/
						{

							A[i][j]=acquisisci_int(0, 99);//leggo l'elemento se � nell intervallo 
														 //lo inserisco in matrice
							
							count++;//aumento il contatore per la verifica iniziale

						}//Passo all'else se sono stati inseriti tutti gli elementi che volevamo

					else A[i][j] = 999;//assegno alla cella inutile infinito
				}

		}
}




/** Procedura KeepYoung
 * Descrizione:
 *  KeepYoung si occupa di controllare
 *  e far rispettare le proprieta' di un tablue di
 *  Young, l'idea � simile alla procedura Heapify,
 *  che controlla se i figli sono maggiori del padre.
 *  Quando viene trovato un elemento che non rispetta
 *  la proprieta'�verra' effettuato uno scambio e successivamente
 *  una chiamata ricorsiva a keepyoung.
 *
 * Complessita' riscontrabili in keepyoung�:
 *  Questo algoritmo nel caso peggiore
 *  e' un O(righe+colonne), perche' dovra'� effettuare
 *  (righe-1)*colonne chiamate ricorsive, o viceversa
 *  (colonne-1)*righe chiamate, per far rispettare
 *  la proprieta' Young
 *
 */
 
void KeepYoung (  int riga, int colonna,int numRig, int numCol, int A[numRig][numCol])
{


	// Variabili per salvare l'elemento minimo, che inizialmente sara' il corrente passato in funzione
	// le altre due variabili, invece, saranno utilizzate per rappresentare le righe e le colonne di tale elemento
	
	int minoreR = riga;//variabile di riga
	int minoreC = colonna;//variabile di colonna
	int minore = A[minoreR][minoreC];//considero l'elemento in posizione assegnata 
	
	/* Ci accingiamo a verificare  se il figlio destro( [i][j+1] ) contiene un elemento
	maggiore del padre e se si stia andando a controllare una colonna oltre il limite*/
	if (( (colonna+1) < numCol) && (A[riga][colonna+1] < minore))
		{

			minore=A[riga][colonna+1];//assegno il valore a destra 
			minoreR=riga;//la riga e' la stessa 
			minoreC=colonna+1;//la colonna e' incrementata 
		}
		
	// Ripetiamo lo stesso procedimento con il figlio sinistro, ( [i+1][j] )
	if (( (riga+1 < numRig)) && (A[riga+1][colonna] < minore))
		{
			minore=A[riga+1][colonna];//assegno il valore sotto 
			minoreR=riga+1;//la riga e' incrementata 
			minoreC=colonna;//la colonna e' la stessa
		}
		
	/*Nel caso in cui si riscontri che il figlio destro o il figlio sinistro sono pi� piccoli
	del padre allora procederemo con lo swap, ovvero con lo scambio tra padre e figlio */
	if (minoreC != colonna || minoreR != riga)

		{

			int tmp = A[riga][colonna];//salvo in temp l'elemento da scambiare 
			A[riga][colonna] = A[minoreR][minoreC];//sovrascrivo l'elemento con quello giusto 
			A[minoreR][minoreC]=tmp;//metto il valore che ha temp nelle matrice 
			KeepYoung(minoreR, minoreC, numRig, numCol,A);//richiamo la funzione a partire da quell
														  //elemento

		}
}




/*
 \ Procedura: 
 \   Print
 \
 \ Descrizione:
 \   La procedura qui di seguito descritta stampa la matrice, ponendo al posto di '999'
 \   il simbolo infinito
 */

void print(int numRig, int numCol, int A[numRig][numCol])
{


	int i;//indice per le rghe 
	int j;//indice per le colonne
	for ( i = 0 ; i < numRig; i++)//ciclo le righe
		{
			for ( j = 0 ; j < numCol; j++)//ciclo le colonne
				{

					if ( A[i][j] == 999 ) // controllo se l'elemento e' 999
						{
							printf("[ oo ]");//allora scrivo infinito
						}
					else
						printf("[ %d ]",A[i][j]);//altrimenti stampo l'elemento

				}
			printf("\n");//spaziatura a capo per ogni colonna
		}
}




/* Procedra: 
 \  BuildYoung
 
 \ Descrizione:
 \  Questa procedura, fara' una scansione completa della matrice
 \  passando gli indici correnti dei due cicli
 \  per richiamare KeepYoung, e controllare che
 \  l'elemento passato rispetti la proprieta'
 \  Young
 \
 \ Complessita': O(log n)
 \
 \
 */
 
void buildYoung (int numRig, int numCol, int A[numRig][numCol])
{

	int rig = numRig;
	int col= numCol;

	int i = 0;//indice riga
	int j=0;//indice colonna

	for ( i = rig-1; i>=0;  i--)//ciclo le righe dall ultima partendo alla prima 
		{

			for ( j = col-1; j>=0; j--)//ciclo le colonne dall ultima partendo alla prima 
				{
					// La procedura buildyoung chiama KeepYoung con gli indici correnti
					KeepYoung( i, j, numRig,numCol, A);
				}

		}
}



/* Funzione :
 \  EstraiMin
 \
 \ Descrizione:
 \  Tale funzione estrae il primo elemento di una tabella Young,
 \  il quale avendo il valore minore risultera' il padre dell'intera struttura,
 \  per poi restituire il numero di elementi decrementato di uno.
 \  Queste azioni potrebbero tornare utili
 \  nella procedura "pulisci", la quale, inizializza
 \  la matrice a tutti oo
 */
 
int  EstraiMin(int numElem, int numRig, int numCol, int A[numRig][numCol])
{

	numElem--;//decremento il numero di elementi avendo tolto il piu piccolo
	// Creo un nuovo elemento indefinito
	A[0][0] = 999;
	// Riordino la tabella secondo Young
	KeepYoung(0,0,numRig,numCol,A);


	return numElem;//restituisce il numero di elementi

}



int search(int chiave, int numRig, int numCol, int A[numRig][numCol])
{

	int trovato=0;//e' una flag per vedere se l'elemento � stato trovato 
	int i;//indice riga
	int j;//indice colonna 
	for ( i = 0 ; i<numRig; i++)//ciclo le righe
		{

			for ( j = 0; j<numCol; j++)//ciclo le colonne
				{

					if (A[i][j] == chiave)//controllo se l'elemento e' presente
						return trovato=trovato+1;//se e' presente  ritorno la flag a 1
				}
		}
	return trovato;//in caso contrario la flag e' 0 come inizializzato 
}





/* Procedura:
 \  KeepYoungReverse
 \ Descrizione:
 \  Questa procedura � il duale di KeepYoung,ovvero il suo opposto.
 \  Essa controlla se la matrice rispetta la regola di keepyoungreverse
 \  dall'ultimo elemento, poiche' chiamata
 \  dalla funzione insert. Tale funzione inserisce un elemento
 \  nell'ultima posizione della matrice e se quest ultima non e' piena controlla
 \  se gli elementi sopra o a sinistra dell'elemnto corrente sono
 \  minori, altrimenti li scambia, allo stesso modo di KeepYoung
 */
 
void KeepYoungReverse(int riga, int colonna, int numRig, int numCol, int A[numRig][numCol])
{

	int maggiore=A[riga][colonna];
	int magR;
	int magC;

	/* Controlla se ci troviamo nei limiti della matrice, e se il l'elemento superiore nella
	 * matrice e' minore dell'elemento corrente.
	 */
	
	if ( ( riga-1 >= 0) && (riga-1 < numRig) && (A[riga-1][colonna] > maggiore))
		{

			maggiore=A[riga-1][colonna];
			magR=riga-1;
			magC=colonna;

		}
		
	// Successivamente ripete la procedura per l'elemento a sinistra del corrente
	if ( ( colonna-1 >=0 ) && (colonna -1 < numCol) && (A[riga][colonna-1] > maggiore))
		{
			maggiore=A[riga][colonna-1];
			magR=riga;
			magC=colonna-1;

		}

	if (maggiore != A[riga][colonna])
		{

			//SWAP
			int tmp = A[riga][colonna];

			A[riga][colonna]=A[magR][magC];

			A[magR][magC]=tmp;

			KeepYoungReverse(magR,magC,numRig,numCol,A);
		}
}




/* Funzione :
 \   insert
 \
 \ Descrizione :
 \  questa funzione serve per inserire un elemento in una matrice gia popolata 
 \ l'idea e di inserire l'elemento e poi spostarlo fino a ridare una struttura solida alla
 \  matrice in fine ritornare il numero di elementi incrementato di uno 
*/

int insert(int numElem, int numRig, int numCol, int A[numRig][numCol])
{

	int ins;//variabile di appoggio
	if ( numElem > numRig*numCol)//controllo se la matrice e' piena 
		{
   
			printf("Piena!!!\n");//stampa il messaggio che e' piena 
             
			return numElem;//ritorna il numero di elementi cosi come era 
		}
	else// altrimenti 
		{ 

			numElem=numElem+1;//incrementa io numero di elemento 

			printf("Inserire elemento:\n");//chiede quale elemento si deve inserire 

			

			A[numRig-1][numCol-1] = acquisisci_int(0,99);//inserisco l'elento nell ultima posizione

			KeepYoungReverse (numRig-1,numCol-1, numRig, numCol, A);//chiamo la funzione 
		}
	return numElem;//ritorna il numero di elementi incrementato
}




/* Funzione :
 \	acquisisci_int
 \
 \ Descrizione:
 \  la funzione prende in input da tastiera l'elemento e successivamente 
 \  controlla se non sfora il dominio impostato dal progettista le variabili a e b sono la
 \  soglia minima e quella massima in caso di esito negativo si deve reinserire il dato 
 \ in caso contrario non ci sono problemi e si va avanti nel codice ;
 */
 
int acquisisci_int(int a, int b)
{
	int n;// variabile di uso per la funzione
	do
		{
			scanf("%d",&n);//legge da tastiera l'elemento 
			if(n<a || n>b) //controlla se il valore si trova nel rango 
				printf("Errore! Input non valido! Riprova: ");//messaggio di errore 
		}
	while(n<a||n>b);//ripete finquando la condizione ha esito negativo
	return n;//ritorna il numero 
}
